package models

type Terminal struct {
	Id        string `json:"id"`
	StationID string `json:"station_id"`
}
