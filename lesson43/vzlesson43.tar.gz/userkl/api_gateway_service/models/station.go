package models

type Station struct {
	Id   string `json:"id"`
	Name string `json:"name"`
}
